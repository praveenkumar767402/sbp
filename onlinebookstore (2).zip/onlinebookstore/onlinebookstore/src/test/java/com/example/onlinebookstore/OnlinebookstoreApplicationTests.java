package com.example.onlinebookstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinebookstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
